# Reconexão — Desafio 21 Dias
Versão limpa com 21 check-ins diferentes e Supabase.

O banco precisa ter a tabela public.challenge_checkins e as políticas RLS do arquivo checkin_migration.sql.
