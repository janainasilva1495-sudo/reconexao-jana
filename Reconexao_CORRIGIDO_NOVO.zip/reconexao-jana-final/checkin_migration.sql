create table if not exists public.challenge_checkins (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  day integer not null check (day between 1 and 21),
  water integer not null default 0 check (water between 0 and 8),
  goals jsonb not null default '{}'::jsonb,
  completed boolean not null default false,
  updated_at timestamptz not null default now(),
  unique (user_id, day)
);
alter table public.challenge_checkins enable row level security;
drop policy if exists "challenge_checkins_select_own" on public.challenge_checkins;
drop policy if exists "challenge_checkins_insert_own" on public.challenge_checkins;
drop policy if exists "challenge_checkins_update_own" on public.challenge_checkins;
drop policy if exists "challenge_checkins_delete_own" on public.challenge_checkins;
create policy "challenge_checkins_select_own" on public.challenge_checkins for select using (auth.uid()=user_id or public.is_admin());
create policy "challenge_checkins_insert_own" on public.challenge_checkins for insert with check (auth.uid()=user_id or public.is_admin());
create policy "challenge_checkins_update_own" on public.challenge_checkins for update using (auth.uid()=user_id or public.is_admin()) with check (auth.uid()=user_id or public.is_admin());
create policy "challenge_checkins_delete_own" on public.challenge_checkins for delete using (auth.uid()=user_id or public.is_admin());
create index if not exists challenge_checkins_user_day_idx on public.challenge_checkins(user_id,day);
